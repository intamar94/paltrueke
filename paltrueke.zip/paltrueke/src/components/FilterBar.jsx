import { Star, AlertTriangle, MapPin, X } from "lucide-react";
import { CATEGORIAS, TIPOS } from "../data/categories";

export default function FilterBar({ filters, setFilters }) {
  const chip = (active) => ({
    flexShrink: 0, display: "flex", alignItems: "center", gap: 5, padding: "6px 12px",
    borderRadius: 20, fontSize: 12.5, fontWeight: 600, border: "1px solid",
    background: active ? "var(--naranja)" : "#fff",
    color: active ? "#fff" : "var(--ink-soft)",
    borderColor: active ? "var(--naranja)" : "#C9C5B8",
  });

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        {[{ id: "todo", label: "Todo" }, ...TIPOS].map((t) => (
          <button
            key={t.id}
            onClick={() => setFilters((f) => ({ ...f, tipo: t.id }))}
            style={{
              flex: 1, padding: "11px 0", borderRadius: 8, border: "1px solid var(--ink)",
              background: filters.tipo === t.id ? "var(--ink)" : "transparent",
              color: filters.tipo === t.id ? "#fff" : "var(--ink)", fontWeight: 600, fontSize: 14,
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
        <button onClick={() => setFilters((f) => ({ ...f, urgente: !f.urgente }))} style={chip(filters.urgente)}>
          <AlertTriangle size={13} /> Urgente
        </button>
        <button onClick={() => setFilters((f) => ({ ...f, mine: !f.mine }))} style={chip(filters.mine)}>
          <Star size={13} fill={filters.mine ? "#fff" : "none"} /> Mis publicaciones
        </button>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12, background: "#fff", border: "1px solid #C9C5B8", borderRadius: 10, padding: "8px 12px" }}>
        <MapPin size={15} color="var(--muted)" style={{ flexShrink: 0 }} />
        <input
          value={filters.zona}
          onChange={(e) => setFilters((f) => ({ ...f, zona: e.target.value }))}
          placeholder="Filtrar por municipio, barrio o departamento…"
          style={{ flex: 1, border: "none", outline: "none", fontSize: 13.5, background: "transparent" }}
        />
        {filters.zona && (
          <button onClick={() => setFilters((f) => ({ ...f, zona: "" }))} style={{ border: "none", background: "none", color: "var(--muted)", display: "flex" }} aria-label="Borrar zona">
            <X size={14} />
          </button>
        )}
      </div>

      <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 6, marginBottom: 14 }}>
        <button onClick={() => setFilters((f) => ({ ...f, categoria: null }))} style={chip(filters.categoria === null)}>
          Todas las categorías
        </button>
        {CATEGORIAS.map((c) => (
          <button
            key={c.id}
            onClick={() => setFilters((f) => ({ ...f, categoria: f.categoria === c.id ? null : c.id }))}
            style={chip(filters.categoria === c.id)}
          >
            {c.emoji} {c.label}
          </button>
        ))}
      </div>
    </div>
  );
}
