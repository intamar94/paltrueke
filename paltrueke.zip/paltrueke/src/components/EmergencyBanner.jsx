import { AlertTriangle, PhoneCall } from "lucide-react";

const EMERGENCIAS = [
  { label: "Emergencias", numero: "123" },
  { label: "Cruz Roja", numero: "132" },
  { label: "Bomberos", numero: "119" },
  { label: "Gestión del riesgo", numero: "144" },
];

export default function EmergencyBanner() {
  return (
    <div
      style={{
        background: "#FDECE5",
        border: "1.5px solid var(--rojo)",
        borderRadius: 10,
        padding: "10px 12px",
      }}
    >
      <div style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 13, marginBottom: 8, color: "var(--ink)" }}>
        <AlertTriangle size={16} color="var(--rojo)" style={{ flexShrink: 0, marginTop: 2 }} />
        <span>
          Si existe <strong>peligro inmediato para la vida</strong>, llama ya. PalTrueke es una red
          de ayuda vecinal y no sustituye a bomberos, policía, Defensa Civil ni Cruz Roja.
        </span>
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
        {EMERGENCIAS.map((e) => (
          <a
            key={e.numero}
            href={`tel:${e.numero}`}
            style={{
              display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 700,
              color: "var(--rojo)", background: "#fff", border: "1px solid var(--rojo)",
              borderRadius: 20, padding: "5px 10px", textDecoration: "none",
            }}
          >
            <PhoneCall size={11} /> {e.label} {e.numero}
          </a>
        ))}
      </div>
    </div>
  );
}
