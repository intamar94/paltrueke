import { LifeBuoy, HeartHandshake, Megaphone, Radio } from "lucide-react";
import EmergencyBanner from "./EmergencyBanner";

// Pantalla de inicio: números de emergencia + accesos directos a
// publicar (Necesito/Ofrezco/Informo) + resumen del estado de la red.
export default function HomeView({ counts, onTipo, onVerTodo }) {
  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "18px 16px 100px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
        <div style={{ width: 34, height: 34, borderRadius: 8, background: "var(--naranja)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Radio size={18} color="var(--ink)" strokeWidth={2.5} />
        </div>
        <h1 className="disp" style={{ fontSize: 30, fontWeight: 800, margin: 0, lineHeight: 1 }}>PALTRUEKE</h1>
      </div>
      <p style={{ margin: "0 0 12px 44px", fontSize: 13, color: "var(--muted)", lineHeight: 1.4 }}>
        Red vecinal para pedir u ofrecer ayuda en emergencias: agua, comida, refugio, transporte y más. Una herramienta hecha por y para la comunidad — cuidémosla entre todos.
      </p>

      <div style={{
        height: 6, borderRadius: 3, marginBottom: 16,
        background: "repeating-linear-gradient(135deg, var(--naranja) 0px, var(--naranja) 10px, var(--ink) 10px, var(--ink) 20px)",
      }} />

      <div style={{ marginBottom: 16 }}>
        <EmergencyBanner />
      </div>

      <div style={{ display: "flex", gap: 1, background: "#33362F", borderRadius: 10, overflow: "hidden", marginBottom: 22 }}>
        {[
          { label: "Necesitan ayuda", value: counts.necesito },
          { label: "Ayuda disponible", value: counts.ofrezco },
          { label: "Información", value: counts.informo },
        ].map((s) => (
          <div key={s.label} style={{ flex: 1, background: "var(--ink)", padding: "10px 6px", textAlign: "center" }}>
            <div className="disp" style={{ fontSize: 24, fontWeight: 700, color: "#F3F1EC", lineHeight: 1 }}>{s.value ?? "—"}</div>
            <div style={{ fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.06em", color: "#8B887C" }}>{s.label}</div>
          </div>
        ))}
      </div>

      <button onClick={() => onTipo("necesito")} style={bigBtn("var(--rojo)")}>
        <LifeBuoy size={24} />
        <span className="disp" style={{ fontSize: 20, fontWeight: 700 }}>NECESITO</span>
      </button>

      <button onClick={() => onTipo("ofrezco")} style={{ ...bigBtn("var(--verde)"), marginTop: 10 }}>
        <HeartHandshake size={24} />
        <span className="disp" style={{ fontSize: 20, fontWeight: 700 }}>OFREZCO</span>
      </button>

      <button onClick={() => onTipo("informo")} style={{ ...bigBtn("var(--info)"), marginTop: 10 }}>
        <Megaphone size={24} />
        <span className="disp" style={{ fontSize: 20, fontWeight: 700 }}>INFORMO</span>
      </button>

      <button onClick={onVerTodo} style={{ width: "100%", marginTop: 16, padding: "12px 0", borderRadius: 10, border: "1px solid var(--ink)", background: "transparent", color: "var(--ink)", fontWeight: 600, fontSize: 14 }}>
        Ver publicaciones
      </button>
    </div>
  );
}

const bigBtn = (bg) => ({
  width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 12,
  padding: "18px 0", borderRadius: 14, border: "none", background: bg, color: "#fff",
  boxShadow: "0 4px 14px rgba(0,0,0,0.15)",
});
