import { useState } from "react";
import { Phone, Radio } from "lucide-react";
import { supabase } from "../lib/supabaseClient";

// Pide el teléfono la primera vez que alguien usa la app. Ese número
// queda fijo como contacto de todas sus publicaciones (ver PostForm),
// y es la base para poder bloquear a alguien si abusa de la red.
export default function PhoneGate({ userId, onDone }) {
  const [telefono, setTelefono] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    const digits = telefono.replace(/\D/g, "");
    if (digits.length < 7) {
      setError("Escribe un número de teléfono válido.");
      return;
    }
    setSaving(true);
    setError("");
    const { error: err } = await supabase.from("profiles").insert({ id: userId, telefono: telefono.trim() });
    if (err) {
      setError("No se pudo guardar. Revisa tu conexión e intenta de nuevo.");
      setSaving(false);
      return;
    }
    onDone(telefono.trim());
  };

  return (
    <div style={{ maxWidth: 420, margin: "60px auto", padding: "0 20px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
        <div style={{ width: 34, height: 34, borderRadius: 8, background: "var(--naranja)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Radio size={18} color="var(--ink)" strokeWidth={2.5} />
        </div>
        <h1 className="disp" style={{ fontSize: 26, fontWeight: 800, margin: 0, lineHeight: 1 }}>PALTRUEKE</h1>
      </div>

      <p style={{ fontSize: 14, color: "var(--ink-soft)", lineHeight: 1.5, marginBottom: 20 }}>
        Antes de empezar, necesitamos un número donde puedan contactarte (WhatsApp o teléfono). Es el mismo que vas a usar en tus publicaciones — así la red sabe que hay una persona real detrás de cada pedido.
      </p>

      <form onSubmit={submit}>
        <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, fontWeight: 600, color: "var(--ink-soft)", marginBottom: 6 }}>
          <Phone size={14} /> Tu número de WhatsApp o teléfono
        </label>
        <input
          value={telefono}
          onChange={(e) => setTelefono(e.target.value)}
          placeholder="Ej: 300 123 4567"
          style={{ width: "100%", padding: "13px 14px", borderRadius: 10, border: "1px solid #C9C5B8", fontSize: 16 }}
          inputMode="tel"
          autoFocus
        />
        {error && <p style={{ color: "var(--rojo)", fontSize: 12.5, marginTop: 8 }}>{error}</p>}

        <button
          type="submit"
          disabled={saving}
          style={{ width: "100%", marginTop: 16, padding: "15px 0", borderRadius: 10, border: "none", background: "var(--naranja)", color: "#fff", fontWeight: 700, fontSize: 16, opacity: saving ? 0.7 : 1 }}
        >
          {saving ? "Guardando…" : "Continuar"}
        </button>

        <p style={{ fontSize: 11, color: "var(--muted)", textAlign: "center", marginTop: 12 }}>
          Solo se usa para que te contacten y para el uso responsable de la red. No se comparte con nadie más que quienes te escriban.
        </p>
      </form>
    </div>
  );
}
