export default function ConfirmDialog({ title, description, onCancel, onConfirm }) {
  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(25,27,24,0.55)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 30, padding: 20 }}
      onClick={onCancel}
    >
      <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 14, padding: 20, maxWidth: 340, width: "100%" }}>
        <h3 className="disp" style={{ fontSize: 19, fontWeight: 700, margin: "0 0 6px" }}>{title}</h3>
        {description && <p style={{ fontSize: 13.5, color: "var(--ink-soft)", margin: "0 0 16px" }}>{description}</p>}
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={onCancel} style={{ flex: 1, padding: "11px 0", borderRadius: 8, border: "1px solid #C9C5B8", background: "#fff", fontWeight: 600, fontSize: 14 }}>
            Cancelar
          </button>
          <button onClick={onConfirm} style={{ flex: 1, padding: "11px 0", borderRadius: 8, border: "none", background: "var(--ink)", color: "#fff", fontWeight: 600, fontSize: 14 }}>
            Confirmar
          </button>
        </div>
      </div>
    </div>
  );
}
