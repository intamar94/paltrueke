import { useState } from "react";
import { X, Phone } from "lucide-react";
import { CATEGORIAS, TIPOS } from "../data/categories";

const EMPTY = {
  tipo: "necesito",
  categoria: "agua",
  descripcion: "",
  urgente: false,
  pais: "Colombia",
  departamento: "",
  municipio: "",
  sector: "",
  contacto: "",
  confirmo: false,
};

// Formulario corto de publicación. El contacto no se pide: viene fijo
// del teléfono con el que la persona se registró (ver PhoneGate).
// Si se le pasa "editingPost", se precarga con esos datos y al guardar
// actualiza en vez de crear una publicación nueva.
export default function PostForm({ initialTipo, defaultContacto, editingPost, onClose, onSubmit }) {
  const [draft, setDraft] = useState(
    editingPost
      ? {
          tipo: editingPost.tipo,
          categoria: editingPost.categoria,
          descripcion: editingPost.descripcion || "",
          urgente: editingPost.urgente,
          pais: editingPost.pais || "Colombia",
          departamento: editingPost.departamento || "",
          municipio: editingPost.municipio || "",
          sector: editingPost.sector || "",
          contacto: editingPost.contacto,
          confirmo: true,
        }
      : { ...EMPTY, tipo: initialTipo || "necesito", contacto: defaultContacto || "" }
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const set = (patch) => setDraft((d) => ({ ...d, ...patch }));

  const submit = async (e) => {
    e.preventDefault();
    if (!draft.descripcion.trim() || !draft.municipio.trim() || !draft.contacto.trim()) {
      setError("Completa descripción, municipio y contacto.");
      return;
    }
    if (!draft.confirmo) {
      setError("Confirma que la información es real para poder publicar.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await onSubmit(draft);
    } catch (err) {
      setError(err?.message || "No se pudo publicar. Revisa tu conexión y prueba de nuevo.");
      setSaving(false);
    }
  };

  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(25,27,24,0.55)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 20 }}
      onClick={onClose}
    >
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        style={{ background: "var(--bg)", width: "100%", maxWidth: 480, borderRadius: "16px 16px 0 0", maxHeight: "88vh", display: "flex", flexDirection: "column" }}
      >
        <div style={{ overflowY: "auto", padding: "20px 20px 8px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h2 className="disp" style={{ fontSize: 22, fontWeight: 700, margin: 0 }}>{editingPost ? "Editar publicación" : "Publicar"}</h2>
            <button type="button" onClick={onClose} style={{ border: "none", background: "none" }} aria-label="Cerrar">
              <X size={20} />
            </button>
          </div>

          <div style={{ display: "flex", gap: 6, marginBottom: 14 }}>
            {TIPOS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => set({ tipo: t.id })}
                style={{
                  flex: 1, padding: "10px 0", borderRadius: 8, fontWeight: 700, fontSize: 13,
                  border: "1.5px solid var(--ink)",
                  background: draft.tipo === t.id ? "var(--ink)" : "transparent",
                  color: draft.tipo === t.id ? "#fff" : "var(--ink)",
                }}
              >
                {t.label}
              </button>
            ))}
          </div>

          <label style={lbl}>Categoría</label>
          <select value={draft.categoria} onChange={(e) => set({ categoria: e.target.value })} style={inp}>
            {CATEGORIAS.map((c) => (
              <option key={c.id} value={c.id}>{c.emoji} {c.label}</option>
            ))}
          </select>

          <label style={lbl}>Descripción</label>
          <textarea
            value={draft.descripcion}
            onChange={(e) => set({ descripcion: e.target.value })}
            placeholder="Cuenta qué pasa: para cuántas personas, urgencia, horarios…"
            style={{ ...inp, minHeight: 80, resize: "vertical" }}
            maxLength={280}
          />

          {draft.tipo !== "informo" && (
            <label style={{ display: "flex", alignItems: "center", gap: 8, margin: "12px 0 4px", fontSize: 14, fontWeight: 600 }}>
              <input type="checkbox" checked={draft.urgente} onChange={(e) => set({ urgente: e.target.checked })} style={{ width: 18, height: 18 }} />
              🔴 Es urgente
            </label>
          )}

          {draft.tipo === "ofrezco" && (
            <p style={{ fontSize: 12, color: "var(--muted)", margin: "4px 0 0", fontStyle: "italic" }}>
              Pon la ubicación desde donde ofreces esto — así te pueden contactar y coordinar cómo retirarlo o recibirlo.
            </p>
          )}

          <label style={{ ...lbl, marginTop: 14 }}>Ubicación</label>
          <div style={{ display: "flex", gap: 8 }}>
            <input value={draft.pais} onChange={(e) => set({ pais: e.target.value })} placeholder="País" style={{ ...inp, flex: 1 }} maxLength={40} />
            <input value={draft.departamento} onChange={(e) => set({ departamento: e.target.value })} placeholder="Departamento" style={{ ...inp, flex: 1 }} maxLength={40} />
          </div>
          <input value={draft.municipio} onChange={(e) => set({ municipio: e.target.value })} placeholder="Municipio" style={{ ...inp, marginTop: 8 }} maxLength={60} />
          <input value={draft.sector} onChange={(e) => set({ sector: e.target.value })} placeholder="Barrio / vereda / sector (opcional)" style={{ ...inp, marginTop: 8 }} maxLength={60} />

          <label style={lbl}>Cómo contactarte</label>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "11px 12px", borderRadius: 8, background: "var(--bg)", border: "1px solid var(--border)" }}>
            <Phone size={15} color="var(--verde)" />
            <span className="disp" style={{ fontSize: 16, fontWeight: 700, color: "var(--ink)" }}>{draft.contacto}</span>
          </div>
          <p style={{ fontSize: 11.5, color: "var(--muted)", margin: "5px 0 0" }}>
            📌 Ese es tu número, el mismo con el que te registraste. Se usa siempre el mismo para que la red sepa quién es quién.
          </p>
        </div>

        <div style={{ padding: "10px 20px 20px", borderTop: "1px solid var(--border)", background: "var(--bg)" }}>
          <label style={{ display: "flex", alignItems: "flex-start", gap: 8, marginBottom: 10, fontSize: 12.5, color: "var(--ink-soft)" }}>
            <input type="checkbox" checked={draft.confirmo} onChange={(e) => set({ confirmo: e.target.checked })} style={{ width: 18, height: 18, marginTop: 1, flexShrink: 0 }} />
            <span>Confirmo que esta información es real. Esta red funciona porque la comunidad confía en lo que se publica.</span>
          </label>
          {error && <p style={{ color: "var(--rojo)", fontSize: 12.5, margin: "0 0 8px" }}>{error}</p>}
          <button
            type="submit"
            disabled={saving}
            style={{ width: "100%", padding: "15px 0", borderRadius: 10, border: "none", background: "var(--naranja)", color: "#fff", fontWeight: 700, fontSize: 16, opacity: saving ? 0.7 : 1 }}
          >
            {saving ? "Guardando…" : editingPost ? "Guardar cambios" : "Publicar"}
          </button>
        </div>
      </form>
    </div>
  );
}

const lbl = { display: "block", fontSize: 12.5, fontWeight: 600, margin: "10px 0 4px", color: "var(--ink-soft)" };
const inp = { width: "100%", padding: "11px 12px", borderRadius: 8, border: "1px solid #C9C5B8", fontSize: 15, background: "#fff", color: "var(--ink)" };
